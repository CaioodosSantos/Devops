let calculo = require ('./development');

test("soma de dois numeros", ()=>{ expect(calculo.add(2,6)).toEqual(8);})

test("subtração de dois numeros", ()=>{ expect(calculo.sub(5,3)).toEqual(2);})

test("mutiplicação de dois numeros", ()=>{ expect(calculo.mut(3,5)).toEqual(15);})

test("divisao de dois numeros", ()=>{ expect(calculo.divi(15,5)).toEqual(3);})
test("divisao de zero", ()=>{ })